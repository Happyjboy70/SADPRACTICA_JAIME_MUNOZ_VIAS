# Práctica 1 de SAD · SecureCorp — Respuestas

**Nombre y apellidos:Jaime Muñoz Vías**
**Usuario: jmunoz**

Responde con tus palabras, en 1-3 líneas. En la defensa te preguntaré lo mismo en voz alta.

**Contraseñas que has usado** (solo porque es un laboratorio; en una empresa, jamás en un fichero):

- Tu usuario:Jmunvia904
- mtorres:Marta2026

---

**1. (A1)** ¿Quién es el `issuer` de tu `ca.crt`? ¿Hasta qué fecha es válido? ¿Por qué el `subject`
y el `issuer` de la CA son iguales y los de `ldap.crt` no?
El issuer del certificado ca.crt es ella misma porque la creamos como un certificado autofirmado, y la fecha de validez es la que pone por defecto al generarla con el script. En la CA el subject y el issuer son iguales porque al ser la raíz absoluta se firma a su propia autoridad, pero en el ldap.crt cambia porque el certificado del servidor LDAP está emitido y firmado por nuestra CA para certificar que es de confianza

**2. (A3)** Pega el comando y el resultado de tus dos búsquedas:

```
a) miembros de rrhh:

ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
dn: cn=rrhh,ou=groups,dc=securecorp,dc=local
member: uid=lromero,ou=people,dc=securecorp,dc=local
member: uid=mtorres,ou=people,dc=securecorp,dc=local


b) cn y mail de todas las personas:
root@CLIENTE:/ldif# ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn mail
dn: uid=lromero,ou=people,dc=securecorp,dc=local
cn: Lucia Romero
mail: lromero@securecorp.local

dn: uid=jmunoz,ou=people,dc=securecorp,dc=local
cn: Jaime Munoz
mail: jmunoz@securecorp.local

dn: uid=mtorres,ou=people,dc=securecorp,dc=local
cn: Marta Torres
mail: mtorres@securecorp.local
```


**3. (A4)** ¿Por qué la clave `ldap.key` tiene que ser de `openldap` y tener permisos 600?
Tiene que pertenecer al usuario openldap porque es el usuario con el que se ejecuta el demonio de LDAP (slapd) en el sistema y necesita permisos para poder leerla al arrancar. Los permisos en 600 (-rw-------) son obligatorios para que solo el propietario pueda leer y escribir en el archivo, evitando que cualquier otro usuario pueda verla y robar la clave privada para hacer un ataque de suplantación.

**4. (A4)** ¿Qué valor has puesto en `SLAPD_SERVICES` y por qué?
Puse ldaps://* ldapi:/// para obligar a que el servicio de LDAP escuche exclusivamente las conexiones seguras cifradas con TLS (en el puerto 636) y mantenga el socket local activo, pasando por completo de dejar conexiones abiertas sin cifrar por la red.

**5. (A4)** Antes de añadir `TLS_CACERT` en el cliente, `ldaps://` no funcionaba. ¿Por qué?
Porque el cliente intentaba conectar por LDAPS, el servidor le soltaba su certificado, pero como el cliente no tenía ni idea de quién era nuestra CA, cortaba la conexión por seguridad al no reconocerlo. Al meter la línea del TLS_CACERT apuntando al ca.crt en el archivo de configuración del cliente, ya le decimos exactamente de qué autoridad debe fiarse.

**6. (B3)** Pega la salida de `klist` con tus dos tickets. ¿Para qué sirve cada uno? ¿Ha viajado tu
contraseña por la red?

```root@CLIENTE:/etc/ldap# klist
Ticket cache: FILE:/tmp/krb5cc_0
Default principal: jmunoz@SECURECORP.LOCAL

Valid starting     Expires            Service principal
10/13/26 17:02:24  10/14/26 03:02:24  krbtgt/SECURECORP.LOCAL@SECURECORP.LOCAL
	renew until 10/20/26 17:02:24
10/13/26 17:02:46  10/14/26 03:02:24  host/web.securecorp.local@SECURECORP.LOCAL
	renew until 10/20/26 17:02:24


```
Al ejecutar el comando se aprecian claramente los dos tickets: el primero (krbtgt/...) es el TGT (Ticket Granting Ticket), que te lo da el KDC al hacer el kinit para demostrar que ya estás autenticado sin necesidad de estar introduciendo la contraseña continuamente; y el segundo (host/web.securecorp.local...) es el ticket de servicio específico que se solicita para acceder de forma segura a una máquina o recurso concreto de la red.
**7. (C)** En el `docker-compose.yml`, ¿qué diferencia hay entre `build:` e `image:`? ¿Qué
significa la línea `- "8081:80"` del servicio `phpldapadmin`?
La diferencia es que build se usa para decirle a Docker que tiene que compilar una imagen desde cero usando un Dockerfile local, mientras que image descarga directamente una imagen ya hecha de un repositorio como Docker Hub. La línea - "8081:80" de phpldapadmin es un mapeo de puertos que coge el puerto 80 de dentro del contenedor y lo saca al puerto 8081 de nuestro equipo para poder entrar a la interfaz web desde el navegador.

**8. (C)** ¿Por qué en la máquina `web` no has tenido que escribir a mano `TLS_CACERT`, y en el
cliente sí? ¿Qué pasaría con esa línea del cliente si hicieras `./lab.sh reset`?
En la máquina web no hizo falta porque dejamos esa línea metida de fábrica dentro de su propio Dockerfile con un comando, haciendo que ya nazca configurada, mientras que en el cliente lo configuramos a mano durante la práctica. Si hicieses un ./lab.sh reset, como el script borra los contenedores y lo deja todo de cero, esa modificación manual que hicimos en el cliente se perdería y dejaría de funcionar el LDAPS hasta que volviéramos a ponerla.
